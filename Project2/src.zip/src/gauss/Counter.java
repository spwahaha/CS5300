package gauss;

public class Counter{
	public static enum counters{
		GLOBALNODE,
		LOOPNUM,
		BLOCKNUM,
		RESIDUALS
	}
}